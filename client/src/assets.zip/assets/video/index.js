export { default as LoginBg } from "../video/login_bg.mp4";
